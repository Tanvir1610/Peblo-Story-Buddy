package com.example.viewmodel

import android.app.Application
import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.TtsManager
import com.example.model.QuizQuestion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import com.example.BuildConfig

enum class BuddyExpression {
    NEUTRAL,
    SPEAKING,
    CELEBRATING,
    DIZZY
}

sealed interface QuizState {
    object Unanswered : QuizState
    data class Correct(val chosenOption: String) : QuizState
    data class Incorrect(val chosenOption: String) : QuizState
}

// Struct to represent a complete story + quiz question
data class StoryNode(
    val title: String,
    val text: String,
    val quizJson: String
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    // -------------------------------------------------------------
    // Constants & Datastore
    // -------------------------------------------------------------
    private val defaultStories = listOf(
        StoryNode(
            title = "Pip's Blue Gear",
            text = "Once upon a time, a clever little robot named Pip lost his shiny blue gear in the Whispering Woods...",
            quizJson = """{
                "question": "What colour was Pip the Robot's lost gear?",
                "options": ["Red", "Green", "Blue", "Yellow"],
                "answer": "Blue"
            }"""
        ),
        StoryNode(
            title = "Lulu's Sparkly Hat",
            text = "Lulu the floppy-eared bunny looked everywhere for her sparkly sun-hat. She finally found it perched on top of a sleepy brown bear's head!",
            quizJson = """{
                "question": "Where did Lulu find her sparkly hat?",
                "options": ["On a tall pine branch", "On a sleeping bear's head", "In the sweet carrot patch"],
                "answer": "On a sleeping bear's head"
            }"""
        ),
        StoryNode(
            title = "Ollie's Midnight Fruit",
            text = "Ollie the Wise old Owl wanted a midnight treat. He flew over golden Indian fields and spotted a delicious juicy red strawberry by the fence.",
            quizJson = """{
                "question": "What midnight snack did Ollie the Owl spot?",
                "options": ["A crunchy yellow acorn", "A sweet purple grape", "A tiny green seed", "A juicy red strawberry", "A slice of golden cheese"],
                "answer": "A juicy red strawberry"
            }"""
        )
    )

    // TTS Controller
    private var ttsManager: TtsManager? = null

    // Observe TTS and current UI States
    private val _ttsState = MutableStateFlow<TtsManager.TtsState>(TtsManager.TtsState.Idle)
    val ttsState = _ttsState.asStateFlow()

    private val _ttsProgress = MutableStateFlow<Float>(0f)
    val ttsProgress = _ttsProgress.asStateFlow()

    // Screen navigation/narrator states
    var currentStoryIndex = mutableStateOf(0)
    var currentStoryText = mutableStateOf(defaultStories[0].text)
    var currentStoryTitle = mutableStateOf(defaultStories[0].title)
    
    // Parsed quiz data
    var currentQuizQuestion = mutableStateOf<QuizQuestion?>(null)
    
    // UI reactive states
    var isQuizRevealed = mutableStateOf(false)
    var quizState = mutableStateOf<QuizState>(QuizState.Unanswered)
    var buddyExpression = mutableStateOf(BuddyExpression.NEUTRAL)
    var hasBlueGear = mutableStateOf(false)
    var collectedCoins = mutableStateOf(0)
    var shakeTrigger = mutableStateOf(false)
    var confettiTrigger = mutableStateOf(false)

    // AI Generation states
    var customTopic = mutableStateOf("")
    var isGeneratingStory = mutableStateOf(false)
    var apiErrorMessage = mutableStateOf<String?>(null)

    // Job tracking for resetting buddy expressions
    private var expressionResetJob: Job? = null

    init {
        // Prepare TTS Manager
        ttsManager = TtsManager(application)
        viewModelScope.launch {
            ttsManager?.state?.collect { state ->
                _ttsState.value = state
                handleTtsStateTransition(state)
            }
        }
        viewModelScope.launch {
            ttsManager?.progress?.collect { progress ->
                _ttsProgress.value = progress
            }
        }
        
        // Load initial story's quiz
        loadQuizFromJson(defaultStories[0].quizJson)
    }

    // Load next/prev story from local bank
    fun selectStory(index: Int) {
        if (index in defaultStories.indices) {
            ttsManager?.stop()
            currentStoryIndex.value = index
            val story = defaultStories[index]
            currentStoryTitle.value = story.title
            currentStoryText.value = story.text
            loadQuizFromJson(story.quizJson)
            
            // Reset state
            isQuizRevealed.value = false
            quizState.value = QuizState.Unanswered
            buddyExpression.value = BuddyExpression.NEUTRAL
            // Only Pip the Robot has the lost blue gear narrative constraint
            hasBlueGear.value = (index == 0 && hasBlueGear.value)
        }
    }

    private fun loadQuizFromJson(jsonStr: String) {
        try {
            val json = JSONObject(jsonStr)
            val questionText = json.getString("question")
            val optionsArray = json.getJSONArray("options")
            val answer = json.getString("answer")

            val optionsList = mutableListOf<String>()
            for (i in 0 until optionsArray.length()) {
                optionsList.add(optionsArray.getString(i))
            }

            currentQuizQuestion.value = QuizQuestion(
                question = questionText,
                options = optionsList,
                answer = answer
            )
        } catch (e: Exception) {
            Log.e("MainViewModel", "Error parsing quiz JSON", e)
        }
    }

    // Trigger story reading
    fun readStory() {
        apiErrorMessage.value = null
        ttsManager?.speak(currentStoryText.value)
    }

    // Stop current speech
    fun stopStory() {
        ttsManager?.stop()
    }

    // Transition state between audio ending and quiz appearing
    private fun handleTtsStateTransition(state: TtsManager.TtsState) {
        when (state) {
            is TtsManager.TtsState.Speaking -> {
                buddyExpression.value = BuddyExpression.SPEAKING
            }
            is TtsManager.TtsState.Success -> {
                // Speech ended successfully! Smoothly reveal the quiz.
                viewModelScope.launch {
                    buddyExpression.value = BuddyExpression.NEUTRAL
                    delay(200) // slight buffer for natural transitions
                    isQuizRevealed.value = true
                }
            }
            is TtsManager.TtsState.Error -> {
                buddyExpression.value = BuddyExpression.NEUTRAL
                apiErrorMessage.value = "TTS Error: ${state.message}. You can still try the quiz below!"
                // Let's reveal quiz as a fallback so children are never blocked!
                isQuizRevealed.value = true
            }
            else -> {
                buddyExpression.value = BuddyExpression.NEUTRAL
            }
        }
    }

    // Handle Option Click inside Quiz
    fun selectQuizOption(option: String) {
        val currentQuiz = currentQuizQuestion.value ?: return
        
        if (option == currentQuiz.answer) {
            // Correct Answer! Clean celebration.
            quizState.value = QuizState.Correct(option)
            buddyExpression.value = BuddyExpression.CELEBRATING
            confettiTrigger.value = true
            
            // If it's Pip's story, fit his lovely blue gear!
            if (currentStoryIndex.value == 0) {
                hasBlueGear.value = true
            }
            
            collectedCoins.value += 10
            
            // Queue simple return to normal buddy after 3.5 seconds of joyful jumping
            scheduleBuddyReset(3500)
        } else {
            // Wrong Answer! Buzzing/Shaking haptics and dizzy eyes.
            quizState.value = QuizState.Incorrect(option)
            buddyExpression.value = BuddyExpression.DIZZY
            shakeTrigger.value = true
            
            // Queue return to normal buddy, and reset shake state
            viewModelScope.launch {
                delay(1000)
                shakeTrigger.value = false
                if (buddyExpression.value == BuddyExpression.DIZZY) {
                    buddyExpression.value = BuddyExpression.NEUTRAL
                }
            }
        }
    }

    private fun scheduleBuddyReset(delayMs: Long) {
        expressionResetJob?.cancel()
        expressionResetJob = viewModelScope.launch {
            delay(delayMs)
            buddyExpression.value = BuddyExpression.NEUTRAL
            confettiTrigger.value = false
        }
    }

    // Reset current story quiz state so child can play again
    fun retryQuiz() {
        quizState.value = QuizState.Unanswered
        buddyExpression.value = BuddyExpression.NEUTRAL
        confettiTrigger.value = false
        if (currentStoryIndex.value == 0) {
            hasBlueGear.value = false
        }
    }

    // -------------------------------------------------------------
    // AI Custom Story & Quiz Creator (Gemini REST Integration)
    // -------------------------------------------------------------
    fun generateStoryFromAi() {
        val topic = customTopic.value.trim()
        if (topic.isEmpty()) {
            apiErrorMessage.value = "Please enter a topic first! (e.g. 'rocket to mars')"
            return
        }

        isGeneratingStory.value = true
        apiErrorMessage.value = null

        viewModelScope.launch(Dispatchers.IO) {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                withContext(Dispatchers.Main) {
                    isGeneratingStory.value = false
                    apiErrorMessage.value = "To use AI, please set your GEMINI_API_KEY in the AI Studio Secrets panel."
                }
                return@launch
            }

            try {
                // Structured Prompt ensuring strict raw JSON return
                val systemPrompt = "You are a playful children's storyteller for edutainment app Peblo. " +
                        "Generate a highly engaging, extremely short story (2-3 sentences, maximum 45 words) suitable for a 6-year-old child. " +
                        "Generate an interactive quiz question based on the story. " +
                        "Return your output as a RAW JSON object with this precise structure: " +
                        "{\"story\": \"Story text...\", \"quiz\": {\"question\": \"Question?\", \"options\": [\"Opt1\", \"Opt2\", \"Opt3\", \"Opt4\"], \"answer\": \"OptX\"}} " +
                        "Rule: The options array MUST contain between 3 to 5 options. One of options MUST exactly match the answer string. " +
                        "Rule: Return ONLY pure JSON. No markdown brackets, no surrounding tags, no ```json formatting."

                val userPrompt = "Create a short story about: $topic"

                val requestBodyText = """
                    {
                      "contents": [
                        {
                          "parts": [
                            { "text": "$userPrompt" }
                          ]
                        }
                      ],
                      "systemInstruction": {
                        "parts": [
                          { "text": "$systemPrompt" }
                        ]
                      },
                      "generationConfig": {
                        "temperature": 0.7,
                        "responseMimeType": "application/json"
                      }
                    }
                """.trimIndent()

                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true
                connection.connectTimeout = 30000
                connection.readTimeout = 30000

                connection.outputStream.use { os ->
                    val input = requestBodyText.toByteArray(Charsets.UTF_8)
                    os.write(input, 0, input.size)
                }

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val responseText = connection.inputStream.bufferedReader().use { it.readText() }
                    
                    // Parse Gemini structure: candidates[0].content.parts[0].text
                    val responseJson = JSONObject(responseText)
                    val candidate = responseJson.getJSONArray("candidates").getJSONObject(0)
                    val contentText = candidate.getJSONObject("content")
                        .getJSONArray("parts").getJSONObject(0).getString("text")

                    // Clean string of any stray markdown if any (just in case they ignored json config)
                    val cleanedJson = contentText.trim()
                        .removePrefix("```json")
                        .removePrefix("```")
                        .removeSuffix("```")
                        .trim()

                    val storyData = JSONObject(cleanedJson)
                    val fetchedStory = storyData.getString("story")
                    val quizData = storyData.getJSONObject("quiz")

                    withContext(Dispatchers.Main) {
                        isGeneratingStory.value = false
                        currentStoryTitle.value = "AI: $topic"
                        currentStoryText.value = fetchedStory
                        loadQuizFromJson(quizData.toString())
                        
                        // Ready for play!
                        isQuizRevealed.value = false
                        quizState.value = QuizState.Unanswered
                        buddyExpression.value = BuddyExpression.NEUTRAL
                        customTopic.value = ""
                    }
                } else {
                    val errorText = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: "HTTP $responseCode"
                    Log.e("MainViewModel", "API Error: $errorText")
                    withContext(Dispatchers.Main) {
                        isGeneratingStory.value = false
                        apiErrorMessage.value = "AI Generation failed (code $responseCode). Please try again."
                    }
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "AI Generation network exception", e)
                withContext(Dispatchers.Main) {
                    isGeneratingStory.value = false
                    apiErrorMessage.value = "Network problem generating story. Check your connection or retry."
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager?.release()
        ttsManager = null
    }
}
