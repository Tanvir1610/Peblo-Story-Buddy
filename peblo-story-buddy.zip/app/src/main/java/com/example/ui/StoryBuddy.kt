package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.TtsManager
import com.example.viewmodel.BuddyExpression
import com.example.viewmodel.QuizState

@Composable
fun StoryBuddy(
    ttsState: TtsManager.TtsState,
    quizState: QuizState,
    hasBlueGear: Boolean,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    // 1. Map current audio playback and quiz state into expressions (Idle, Speaking, Happy/Celebrating, Dizzy)
    val expression = remember(ttsState, quizState) {
        when {
            quizState is QuizState.Correct -> BuddyExpression.CELEBRATING
            quizState is QuizState.Incorrect -> BuddyExpression.DIZZY
            ttsState is TtsManager.TtsState.Speaking -> BuddyExpression.SPEAKING
            else -> BuddyExpression.NEUTRAL
        }
    }

    // 2. Playful background glow color according to the active mood/state
    val backgroundGlow = remember(expression) {
        when (expression) {
            BuddyExpression.SPEAKING -> Brush.radialGradient(
                colors = listOf(Color(0xFFFEF08A).copy(alpha = 0.45f), Color(0xFFF1F5F9)),
                radius = 450f
            )
            BuddyExpression.CELEBRATING -> Brush.radialGradient(
                colors = listOf(Color(0xFFBBF7D0).copy(alpha = 0.45f), Color(0xFFF1F5F9)),
                radius = 450f
            )
            BuddyExpression.DIZZY -> Brush.radialGradient(
                colors = listOf(Color(0xFFFECACA).copy(alpha = 0.4f), Color(0xFFF1F5F9)),
                radius = 450f
            )
            else -> Brush.radialGradient(
                colors = listOf(Color(0xFFE2E8F0).copy(alpha = 0.25f), Color(0xFFF1F5F9)),
                radius = 450f
            )
        }
    }

    // Interactive scale animation when clicked
    var isClicked by remember { mutableStateOf(false) }
    val scaleValue by animateFloatAsState(
        targetValue = if (isClicked) 0.95f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        finishedListener = { isClicked = false },
        label = "click_scale"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .scale(scaleValue)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                isClicked = true
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // High fidelity outer character box with active theme feedback
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(170.dp)
                .background(backgroundGlow, shape = RoundedCornerShape(20.dp))
                .border(
                    width = 1.5.dp,
                    color = when (expression) {
                        BuddyExpression.SPEAKING -> Color(0xFFEAB308).copy(alpha = 0.5f)
                        BuddyExpression.CELEBRATING -> Color(0xFF22C55E).copy(alpha = 0.5f)
                        BuddyExpression.DIZZY -> Color(0xFFEF4444).copy(alpha = 0.5f)
                        else -> Color(0xFFE2E8F0)
                    },
                    shape = RoundedCornerShape(20.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            // Crossed structural guidelines (matching wireframe motif beautifully)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        drawLine(
                            color = Color(0xFFCBD5E1).copy(alpha = 0.25f),
                            start = Offset(0f, 0f),
                            end = Offset(size.width, size.height),
                            strokeWidth = 1.dp.toPx()
                        )
                        drawLine(
                            color = Color(0xFFCBD5E1).copy(alpha = 0.25f),
                            start = Offset(0f, size.height),
                            end = Offset(size.width, 0f),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
            )

            // Actual animated buddy custom drawing
            BuddyCanvas(
                expression = expression,
                hasBlueGear = hasBlueGear,
                modifier = Modifier
                    .testTag("pip_companion_buddy")
                    .scale(1.18f)
            )

            // Soft Floating Mood Pill Badge in the top corner
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .background(
                        color = when (expression) {
                            BuddyExpression.SPEAKING -> Color(0xFFFEF08A)
                            BuddyExpression.CELEBRATING -> Color(0xFFDCFCE7)
                            BuddyExpression.DIZZY -> Color(0xFFFEE2E2)
                            else -> Color(0xFFF1F5F9)
                        },
                        shape = RoundedCornerShape(100)
                    )
                    .border(
                        width = 1.dp,
                        color = when (expression) {
                            BuddyExpression.SPEAKING -> Color(0xFFEAB308).copy(alpha = 0.3f)
                            BuddyExpression.CELEBRATING -> Color(0xFF22C55E).copy(alpha = 0.3f)
                            BuddyExpression.DIZZY -> Color(0xFFEF4444).copy(alpha = 0.3f)
                            else -> Color(0xFFE2E8F0)
                        },
                        shape = RoundedCornerShape(100)
                    )
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val indicatorColor = when (expression) {
                        BuddyExpression.SPEAKING -> Color(0xFFCA8A04)
                        BuddyExpression.CELEBRATING -> Color(0xFF16A34A)
                        BuddyExpression.DIZZY -> Color(0xFFDC2626)
                        else -> Color(0xFF475569)
                    }
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .background(indicatorColor, CircleShape)
                    )
                    Text(
                        text = when (expression) {
                            BuddyExpression.SPEAKING -> "Speaking"
                            BuddyExpression.CELEBRATING -> "Happy"
                            BuddyExpression.DIZZY -> "Dizzy"
                            else -> "Idle"
                        },
                        color = indicatorColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Pip name label
        Text(
            text = "Pip the Robot",
            color = MidnightIndigo,
            fontSize = 19.sp,
            fontWeight = FontWeight.ExtraBold
        )

        Spacer(modifier = Modifier.height(2.dp))

        // Dynamic reactive speech bubble / quote text based on status
        AnimatedContent(
            targetState = expression,
            transitionSpec = {
                (slideInVertically { height -> height } + fadeIn() togetherWith
                        slideOutVertically { height -> -height } + fadeOut())
                    .using(SizeTransform(clip = false))
            },
            label = "buddy_expression_text"
        ) { activeExpression ->
            val descriptionText = when (activeExpression) {
                BuddyExpression.SPEAKING -> "Listening closely... Pip is reading! 🔊"
                BuddyExpression.CELEBRATING -> "Yay! You got it correct! 🌟 +10 Coins!"
                BuddyExpression.DIZZY -> "Oops, that's not quite right! Try again! 💫"
                else -> {
                    if (ttsState is TtsManager.TtsState.Preparing) {
                        "Pip is preparing the voice track... 🤫"
                    } else {
                        "Tap 'Read Me a Story' below to start reading! 📖"
                    }
                }
            }
            Text(
                text = descriptionText,
                color = when (activeExpression) {
                    BuddyExpression.SPEAKING -> Color(0xFFCA8A04)
                    BuddyExpression.CELEBRATING -> Color(0xFF16A34A)
                    BuddyExpression.DIZZY -> Color(0xFFDC2626)
                    else -> MutedText
                },
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            )
        }
    }
}
