package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.example.viewmodel.BuddyExpression
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BuddyCanvas(
    expression: BuddyExpression,
    hasBlueGear: Boolean,
    modifier: Modifier = Modifier
) {
    // -------------------------------------------------------------
    // 1. Animations & States
    // -------------------------------------------------------------
    
    // Continuous Breathing (Idle) Animation
    val infiniteTransition = rememberInfiniteTransition(label = "breathe")
    val breatheOffset by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathe_offset"
    )

    // Continuous Spinner rotation (for Pip's side gears)
    val gearRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "gear_rotation"
    )

    // Pulse animation (for custom antenna light in speech mode)
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Dynamic eyes blink sequence
    var blinkState by remember { mutableStateOf(1f) }
    LaunchedEffect(key1 = expression) {
        while (true) {
            // Blink every 3-5 seconds
            val delayMillis = (3000..6000).random().toLong()
            kotlinx.coroutines.delay(delayMillis)
            
            // Fast blink animating eye scale down and up
            val duration = 120
            val startTime = System.currentTimeMillis()
            while (true) {
                val progress = (System.currentTimeMillis() - startTime).toFloat() / duration
                if (progress >= 1f) {
                    blinkState = 1f
                    break
                }
                blinkState = if (progress < 0.5f) {
                    // close eye
                    1f - (progress * 2)
                } else {
                    // open eye
                    (progress - 0.5f) * 2
                }
                kotlinx.coroutines.delay(16)
            }
        }
    }

    // Celebrating jump animation (when Correct answer is tapped)
    val jumpOffset = remember { Animatable(0f) }
    LaunchedEffect(key1 = expression) {
        if (expression == BuddyExpression.CELEBRATING) {
            // Do twice a joyful jump animation
            repeat(3) {
                jumpOffset.animateTo(-25f, animationSpec = tween(180, easing = EaseOutQuad))
                jumpOffset.animateTo(0f, animationSpec = tween(180, easing = EaseInQuad))
            }
        } else {
            jumpOffset.snapTo(0f)
        }
    }

    // Dizzy shake animation (when Incorrect answer is tapped)
    val dizzyShake = remember { Animatable(0f) }
    LaunchedEffect(key1 = expression) {
        if (expression == BuddyExpression.DIZZY) {
            repeat(4) {
                dizzyShake.animateTo(12f, animationSpec = tween(50, easing = EaseInOutQuad))
                dizzyShake.animateTo(-12f, animationSpec = tween(50, easing = EaseInOutQuad))
            }
            dizzyShake.animateTo(0f, animationSpec = tween(50, easing = EaseInOutQuad))
        } else {
            dizzyShake.snapTo(0f)
        }
    }

    // -------------------------------------------------------------
    // 2. Rendering the Canvas
    // -------------------------------------------------------------
    Canvas(
        modifier = modifier
            .size(190.dp)
            .padding(8.dp)
    ) {
        val width = size.width
        val height = size.height
        
        // Base coordinate shifts
        val currentJumpY = jumpOffset.value
        val currentShakeX = dizzyShake.value
        
        // Center of the canvas
        val centerX = width / 2f
        val centerY = (height / 2f) + breatheOffset + currentJumpY

        // ----------------- DRAW ANTENNA -----------------
        val antennaX = centerX + currentShakeX
        val antennaTopY = centerY - 105f
        val antennaBaseY = centerY - 55f
        
        // Antenna Pole
        drawLine(
            color = Color(0xFF242430),
            start = Offset(antennaX, antennaBaseY),
            end = Offset(antennaX, antennaTopY),
            strokeWidth = 6.dp.toPx(),
            cap = StrokeCap.Round
        )
        
        // Glowing bulb at the top
        val bulbColor = when (expression) {
            BuddyExpression.SPEAKING -> Color(0xFFFF9E00) // Speaking glowing orange
            BuddyExpression.CELEBRATING -> Color(0xFFFFD60A) // Happy yellow glow
            BuddyExpression.DIZZY -> Color(0xFFFF5252) // Red error flash
            else -> Color(0xFF17B890) // Normal friendly mint-teal
        }
        
        val currentBulbRadius = 14.dp.toPx() * if (expression == BuddyExpression.SPEAKING) pulseScale else 1f
        
        // Outer halo glow
        drawCircle(
            color = bulbColor.copy(alpha = 0.3f),
            radius = currentBulbRadius + 8.dp.toPx(),
            center = Offset(antennaX, antennaTopY)
        )
        // Solid bulb center
        drawCircle(
            color = bulbColor,
            radius = currentBulbRadius,
            center = Offset(antennaX, antennaTopY)
        )
        // Outline
        drawCircle(
            color = Color(0xFF242430),
            radius = currentBulbRadius,
            center = Offset(antennaX, antennaTopY),
            style = Stroke(width = 3.dp.toPx())
        )

        // ----------------- DRAW SIDE GEAR EARS -----------------
        // Left Gear: Stays metallic/gray
        val leftGearX = centerX - 65.dp.toPx() + currentShakeX
        val leftGearY = centerY
        rotate(gearRotation, pivot = Offset(leftGearX, leftGearY)) {
            // Under layer (Chunky outline)
            drawGear(leftGearX, leftGearY, 20.dp.toPx(), 23.dp.toPx(), Color(0xFF242430))
            drawGear(leftGearX, leftGearY, 12.dp.toPx(), 19.dp.toPx(), Color(0xFFADB5BD))
            drawCircle(Color(0xFF242430), 5.dp.toPx(), Offset(leftGearX, leftGearY))
        }

        // Right Gear: This represents Pip's lost shiny BLUE gear!
        // If he doesn't have it (default story start), it is drawn as a grey outline or missing center.
        // Once correct, it renders as a beautiful, glowing shiny BLUE gear!
        val rightGearX = centerX + 65.dp.toPx() + currentShakeX
        val rightGearY = centerY
        
        rotate(-gearRotation, pivot = Offset(rightGearX, rightGearY)) {
            if (hasBlueGear) {
                // Shiny vibrant blue gear with gold accent center!
                drawGear(rightGearX, rightGearY, 20.dp.toPx(), 23.dp.toPx(), Color(0xFF242430))
                drawGear(rightGearX, rightGearY, 12.dp.toPx(), 19.dp.toPx(), Color(0xFF3A86FF))
                drawCircle(Color(0xFFFFD60A), 6.dp.toPx(), Offset(rightGearX, rightGearY))
                drawCircle(Color(0xFF242430), 6.dp.toPx(), Offset(rightGearX, rightGearY), style = Stroke(width = 2.dp.toPx()))
            } else {
                // Lost gear slot: drawn as a gray dotted outline, showing vacancy
                drawCircle(
                    color = Color(0xFFCED4DA),
                    radius = 16.dp.toPx(),
                    center = Offset(rightGearX, rightGearY),
                    style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                )
                drawCircle(
                    color = Color(0xFF6C757D),
                    radius = 4.dp.toPx(),
                    center = Offset(rightGearX, rightGearY)
                )
            }
        }

        // ----------------- DRAW ROBOT FACE SURFACE -----------------
        val faceWidth = 112.dp.toPx()
        val faceHeight = 92.dp.toPx()
        val faceLeft = centerX - (faceWidth / 2f) + currentShakeX
        val faceTop = centerY - (faceHeight / 2f)
        
        // 3D Shadow/Depth Offset (Chunkiness!)
        drawRoundRect(
            color = Color(0xFF242430),
            topLeft = Offset(faceLeft + 4.dp.toPx(), faceTop + 6.dp.toPx()),
            size = Size(faceWidth, faceHeight),
            cornerRadius = CornerRadius(22.dp.toPx(), 22.dp.toPx())
        )
        
        // Core Face Panel (Bright orange robot plates!)
        val faceColor = Color(0xFFFFA200) // Friendly safety yellow-orange
        drawRoundRect(
            color = faceColor,
            topLeft = Offset(faceLeft, faceTop),
            size = Size(faceWidth, faceHeight),
            cornerRadius = CornerRadius(22.dp.toPx(), 22.dp.toPx())
        )
        
        // Inner screen/visor for eyes (Deep blue-black glossy screen)
        val visorWidth = 92.dp.toPx()
        val visorHeight = 44.dp.toPx()
        val visorLeft = centerX - (visorWidth / 2f) + currentShakeX
        val visorTop = centerY - 32.dp.toPx()
        
        drawRoundRect(
            color = Color(0xFF151821), // Dark space blue visor
            topLeft = Offset(visorLeft, visorTop),
            size = Size(visorWidth, visorHeight),
            cornerRadius = CornerRadius(14.dp.toPx(), 14.dp.toPx())
        )
        
        // Outer Face plate border line
        drawRoundRect(
            color = Color(0xFF242430),
            topLeft = Offset(faceLeft, faceTop),
            size = Size(faceWidth, faceHeight),
            cornerRadius = CornerRadius(22.dp.toPx(), 22.dp.toPx()),
            style = Stroke(width = 4.dp.toPx())
        )

        // ----------------- DRAW EYES ON VISOR -----------------
        val leftEyeCenterX = centerX - 24.dp.toPx() + currentShakeX
        val rightEyeCenterX = centerX + 24.dp.toPx() + currentShakeX
        val eyesY = centerY - 10.dp.toPx()
        
        when (expression) {
            BuddyExpression.DIZZY -> {
                // Dizzy eyes: small red "X"s
                drawCrossEye(leftEyeCenterX, eyesY, 6.dp.toPx(), Color(0xFFFF5252))
                drawCrossEye(rightEyeCenterX, eyesY, 6.dp.toPx(), Color(0xFFFF5252))
            }
            BuddyExpression.CELEBRATING -> {
                // Happy eyes: beautiful golden stars!
                drawStarEye(leftEyeCenterX, eyesY, 9.dp.toPx(), Color(0xFFFFD60A))
                drawStarEye(rightEyeCenterX, eyesY, 9.dp.toPx(), Color(0xFFFFD60A))
            }
            BuddyExpression.SPEAKING -> {
                // Speech wave animation eyes: alternating sound rings
                val waveLeft = 8.dp.toPx() + (sin(System.currentTimeMillis() / 150.0).toFloat() * 3.dp.toPx())
                val waveRight = 8.dp.toPx() + (cos(System.currentTimeMillis() / 150.0).toFloat() * 3.dp.toPx())
                
                // Left Eye ring
                drawCircle(Color(0xFF00F5D4), radius = waveLeft + 2f, center = Offset(leftEyeCenterX, eyesY))
                drawCircle(Color(0xFF151821), radius = waveLeft - 2f, center = Offset(leftEyeCenterX, eyesY))
                
                // Right Eye ring
                drawCircle(Color(0xFF00F5D4), radius = waveRight + 2f, center = Offset(rightEyeCenterX, eyesY))
                drawCircle(Color(0xFF151821), radius = waveRight - 2f, center = Offset(rightEyeCenterX, eyesY))
            }
            else -> {
                // Idle friendly circular eyes (with blink state)
                val baseEyeRadius = 9.dp.toPx()
                val currentEyeHeight = baseEyeRadius * blinkState
                
                // Left eye
                drawRobotOval(
                    color = Color(0xFF00F5D4), // Cyan glowing eyes
                    valLeft = leftEyeCenterX - baseEyeRadius,
                    valTop = eyesY - currentEyeHeight,
                    valWidth = baseEyeRadius * 2f,
                    valHeight = currentEyeHeight * 2f
                )
                // Left eye reflection highlight (if eye open)
                if (blinkState > 0.4f) {
                    drawCircle(
                        color = Color.White,
                        radius = 2.5f.dp.toPx(),
                        center = Offset(leftEyeCenterX - 3.dp.toPx(), eyesY - 3.dp.toPx())
                    )
                }

                // Right eye
                drawRobotOval(
                    color = Color(0xFF00F5D4),
                    valLeft = rightEyeCenterX - baseEyeRadius,
                    valTop = eyesY - currentEyeHeight,
                    valWidth = baseEyeRadius * 2f,
                    valHeight = currentEyeHeight * 2f
                )
                // Right eye reflection highlight
                if (blinkState > 0.4f) {
                    drawCircle(
                        color = Color.White,
                        radius = 2.5f.dp.toPx(),
                        center = Offset(rightEyeCenterX - 3.dp.toPx(), eyesY - 3.dp.toPx())
                    )
                }
            }
        }

        // ----------------- DRAW CUTE SMILEY MOUTH -----------------
        val mouthY = centerY + 24.dp.toPx()
        val mouthWidth = 28.dp.toPx()
        
        when (expression) {
            BuddyExpression.DIZZY -> {
                // Squiggly dizzy/sad mouth
                val path = Path().apply {
                    moveTo(centerX - 10.dp.toPx() + currentShakeX, mouthY)
                    quadraticTo(
                        centerX - 5.dp.toPx() + currentShakeX, mouthY - 4.dp.toPx(),
                        centerX + currentShakeX, mouthY
                    )
                    quadraticTo(
                        centerX + 5.dp.toPx() + currentShakeX, mouthY + 4.dp.toPx(),
                        centerX + 10.dp.toPx() + currentShakeX, mouthY
                    )
                }
                drawPath(
                    path = path,
                    color = Color(0xFF242430),
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            BuddyExpression.CELEBRATING -> {
                // Wide open joyful grinning mouth (big dynamic semi-circle)
                val rect = Rect(
                    left = centerX - 14.dp.toPx() + currentShakeX,
                    top = mouthY - 6.dp.toPx(),
                    right = centerX + 14.dp.toPx() + currentShakeX,
                    bottom = mouthY + 14.dp.toPx()
                )
                val path = Path().apply {
                    arcTo(rect, startAngleDegrees = 0f, sweepAngleDegrees = 180f, forceMoveTo = true)
                    close()
                }
                // Fill mouth interior
                drawPath(path = path, color = Color(0xFFFF5252))
                // Draw white little teeth at top of mouth
                drawRect(
                    color = Color.White,
                    topLeft = Offset(centerX - 8.dp.toPx() + currentShakeX, mouthY - 4.dp.toPx()),
                    size = Size(16.dp.toPx(), 4.dp.toPx())
                )
                // Mouth border
                drawPath(
                    path = path,
                    color = Color(0xFF242430),
                    style = Stroke(width = 3.dp.toPx())
                )
            }
            BuddyExpression.SPEAKING -> {
                // Speaking - round talking circle mouth
                val sizeVal = 10.dp.toPx() + (sin(System.currentTimeMillis() / 80.0).toFloat() * 3.dp.toPx())
                drawCircle(
                    color = Color(0xFFFF5252),
                    radius = sizeVal,
                    center = Offset(centerX + currentShakeX, mouthY)
                )
                drawCircle(
                    color = Color(0xFF242430),
                    radius = sizeVal,
                    center = Offset(centerX + currentShakeX, mouthY),
                    style = Stroke(width = 3.dp.toPx())
                )
            }
            else -> {
                // Neutral state - sweet simple cheeky smile curve
                val path = Path().apply {
                    moveTo(centerX - 12.dp.toPx() + currentShakeX, mouthY - 2.dp.toPx())
                    quadraticTo(
                        centerX + currentShakeX, mouthY + 8.dp.toPx(),
                        centerX + 12.dp.toPx() + currentShakeX, mouthY - 2.dp.toPx()
                    )
                }
                drawPath(
                    path = path,
                    color = Color(0xFF242430),
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )
                // Rosy cheeks (little pink blush ovals)
                drawCircle(
                    color = Color(0xFFFFD6BA).copy(alpha = 0.8f),
                    radius = 5.dp.toPx(),
                    center = Offset(faceLeft + 16.dp.toPx(), mouthY - 4.dp.toPx())
                )
                drawCircle(
                    color = Color(0xFFFFD6BA).copy(alpha = 0.8f),
                    radius = 5.dp.toPx(),
                    center = Offset(faceLeft + faceWidth - 16.dp.toPx(), mouthY - 4.dp.toPx())
                )
            }
        }
    }
}

// -------------------------------------------------------------
// Canvas Helper Drawing Actions
// -------------------------------------------------------------

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRobotOval(
    color: Color,
    valLeft: Float,
    valTop: Float,
    valWidth: Float,
    valHeight: Float
) {
    this.drawOval(
        color = color,
        topLeft = Offset(valLeft, valTop),
        size = Size(valWidth, valHeight)
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCrossEye(
    x: Float,
    y: Float,
    sizeVal: Float,
    color: Color
) {
    drawLine(
        color = color,
        start = Offset(x - sizeVal, y - sizeVal),
        end = Offset(x + sizeVal, y + sizeVal),
        strokeWidth = 3.dp.toPx(),
        cap = StrokeCap.Round
    )
    drawLine(
        color = color,
        start = Offset(x + sizeVal, y - sizeVal),
        end = Offset(x - sizeVal, y + sizeVal),
        strokeWidth = 3.dp.toPx(),
        cap = StrokeCap.Round
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawStarEye(
    cx: Float,
    cy: Float,
    maxRadius: Float,
    color: Color
) {
    val path = Path()
    val pointsCount = 5
    var angle = -PI / 2
    val deltaAngle = PI / pointsCount
    
    for (i in 0 until (pointsCount * 2)) {
        val r = if (i % 2 == 0) maxRadius else maxRadius / 2.2f
        val currX = cx + (r * cos(angle)).toFloat()
        val currY = cy + (r * sin(angle)).toFloat()
        if (i == 0) path.moveTo(currX, currY) else path.lineTo(currX, currY)
        angle += deltaAngle
    }
    path.close()
    
    // Fill Star
    drawPath(path = path, color = color)
    // Draw thin outline
    drawPath(path = path, color = Color(0xFF242430), style = Stroke(width = 2.dp.toPx()))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGear(
    cx: Float,
    cy: Float,
    innerRadius: Float,
    outerRadius: Float,
    color: Color
) {
    val teethCount = 8
    val path = Path()
    
    for (i in 0 until teethCount) {
        val angleBase = (i * 2 * PI / teethCount)
        
        // Tooth corners
        val x1 = cx + (innerRadius * cos(angleBase - 0.15)).toFloat()
        val y1 = cy + (innerRadius * sin(angleBase - 0.15)).toFloat()
        
        val x2 = cx + (outerRadius * cos(angleBase - 0.08)).toFloat()
        val y2 = cy + (outerRadius * sin(angleBase - 0.08)).toFloat()
        
        val x3 = cx + (outerRadius * cos(angleBase + 0.08)).toFloat()
        val y3 = cy + (outerRadius * sin(angleBase + 0.08)).toFloat()
        
        val x4 = cx + (innerRadius * cos(angleBase + 0.15)).toFloat()
        val y4 = cy + (innerRadius * sin(angleBase + 0.15)).toFloat()
        
        if (i == 0) {
            path.moveTo(x1, y1)
        } else {
            path.lineTo(x1, y1)
        }
        path.lineTo(x2, y2)
        path.lineTo(x3, y3)
        path.lineTo(x4, y4)
    }
    path.close()
    
    // Core circle structure
    path.addOval(Rect(cx - innerRadius, cy - innerRadius, cx + innerRadius, cy + innerRadius))
    
    drawPath(path = path, color = color)
}
