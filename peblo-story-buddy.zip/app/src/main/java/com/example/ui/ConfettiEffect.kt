package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.random.Random

private data class Particle(
    var x: Float,
    var y: Float,
    val color: Color,
    val width: Float,
    val height: Float,
    val speedY: Float,
    val speedX: Float,
    var angle: Float,
    val rotationSpeed: Float
)

@Composable
fun ConfettiEffect(
    trigger: Boolean,
    modifier: Modifier = Modifier
) {
    if (!trigger) return

    val particles = remember { mutableStateListOf<Particle>() }
    
    // Colorful, cheerful child-friendly confetti paints!
    val colors = listOf(
        Color(0xFFFF6B4A), // Coral
        Color(0xFFFFD60A), // Gold
        Color(0xFF17B890), // Leaf
        Color(0xFF3A86FF), // Sky
        Color(0xFF8338EC), // Purple
        Color(0xFFFF006E)  // Hot pink
    )

    // Setup loop trigger using withFrameMillis to guarantee smooth updates matching device screen refresh rate!
    var frameTime by remember { mutableStateOf(0L) }
    LaunchedEffect(key1 = trigger) {
        // Build 75 particles at randomized horizontal locations above screen
        particles.clear()
        for (i in 0 until 80) {
            particles.add(
                Particle(
                    x = Random.nextFloat() * 1000f, // Initial X (updated in canvas onSizeChanged)
                    y = -Random.nextFloat() * 400f - 50f, // Start above the screen
                    color = colors.random(),
                    width = Random.nextFloat() * 12f + 12f,
                    height = Random.nextFloat() * 24f + 16f,
                    speedY = Random.nextFloat() * 8f + 6f, // Falling velocity
                    speedX = (Random.nextFloat() - 0.5f) * 4f, // Sway/wind speed
                    angle = Random.nextFloat() * 360f,
                    rotationSpeed = (Random.nextFloat() - 0.5f) * 15f
                )
            )
        }

        // Animation frame loop
        while (true) {
            withFrameMillis { time ->
                frameTime = time
                
                // Update every particle's coordinates
                particles.forEach { p ->
                    p.y += p.speedY
                    p.x += p.speedX + (kotlin.math.sin(p.y / 30f) * 1.5f).toFloat() // swaying wind
                    p.angle = (p.angle + p.rotationSpeed) % 360f
                }
            }
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        particles.forEach { p ->
            // If horizontal pos goes out of layout widths, wrap around
            if (p.x < 0) p.x = width
            if (p.x > width) p.x = 0f
            
            // Only draw particles still visible inside current heights
            if (p.y in -100f..height + 100f) {
                // Adapt initial coordinates mapping once canvas size is resolved
                if (p.x > width) {
                    p.x = Random.nextFloat() * width
                }

                rotate(p.angle, pivot = Offset(p.x, p.y)) {
                    drawRect(
                        color = p.color,
                        topLeft = Offset(p.x - p.width / 2, p.y - p.height / 2),
                        size = Size(p.width, p.height)
                    )
                }
            }
        }
    }
}
