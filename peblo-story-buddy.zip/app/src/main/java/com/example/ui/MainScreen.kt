package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.QuizQuestion
import com.example.viewmodel.BuddyExpression
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.QuizState
import com.example.audio.TtsManager
import kotlinx.coroutines.delay

// --- Playful Comic design styling constants ---
val BorderDark = Color(0xFF242430)
val BackgroundCream = Color(0xFFFFFDEB)
val PebloCoral = Color(0xFFFF6B4A)
val PebloGold = Color(0xFFFFC300)
val PebloMint = Color(0xFF17B890)
val PebloSky = Color(0xFF3A86FF)
val PebloAmethyst = Color(0xFF8338EC)

// --- Wireframe Style Guidance Palette ---
val PrimaryPurple = Color(0xFF6F2BC2)
val MidnightIndigo = Color(0xFF36165E)
val LightBg = Color(0xFFF8F9FA)
val BorderLight = Color(0xFFE6E8F0)
val DarkText = Color(0xFF1E293B)
val MutedText = Color(0xFF64748B)

// Map existing variables for clean styling throughout components
val ImmersiveBg = LightBg
val ImmersiveTextMain = DarkText
val ImmersiveTextDark = MidnightIndigo
val ImmersiveTextSub = MutedText
val ImmersiveCyan = PrimaryPurple
val ImmersiveOrange = PrimaryPurple
val ImmersiveYellow = Color(0xFFFFD166)
val ImmersivePipBg = Color(0xFFF1F5F9)
val ImmersiveQuizBg = Color.White
val ImmersiveQuizBorder = BorderLight
val ImmersiveCardBorder = BorderLight

// Shake Modifier for incorrect selections
fun Modifier.shake(trigger: Boolean) = if (trigger) {
    this.graphicsLayer {
        this.translationX = (kotlin.math.sin(System.currentTimeMillis() / 25.0) * 12).toFloat()
    }
} else {
    this
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val scrollState = rememberScrollState()
    val haptic = LocalHapticFeedback.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current

    // Observe TTS Audio States
    val ttsState by viewModel.ttsState.collectAsState()
    val ttsProgress by viewModel.ttsProgress.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ImmersiveBg)
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // -------------------------------------------------------------
            // 1. App Header with Hamburger, Title & Profile (Wireframe Match)
            // -------------------------------------------------------------
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Menu,
                            contentDescription = "Menu",
                            tint = PrimaryPurple,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AI Story Buddy",
                        color = PrimaryPurple,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.SansSerif
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically, 
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Coins Score Tracker Box
                    Row(
                        modifier = Modifier
                            .shadow(elevation = 1.dp, shape = RoundedCornerShape(100))
                            .background(
                                color = Color.White,
                                shape = RoundedCornerShape(100)
                            )
                            .border(1.dp, PrimaryPurple.copy(alpha = 0.15f), RoundedCornerShape(100))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${viewModel.collectedCoins.value}",
                            color = PrimaryPurple,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .background(ImmersiveYellow, shape = CircleShape)
                        )
                    }

                    IconButton(
                        onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AccountCircle,
                            contentDescription = "Profile",
                            tint = PrimaryPurple,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            // -------------------------------------------------------------
            // 2. StoryBuddy Character Widget (Wireframe Image 1 Match)
            // -------------------------------------------------------------
            ComicCard(
                backgroundColor = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    StoryBuddy(
                        ttsState = ttsState,
                        quizState = viewModel.quizState.value,
                        hasBlueGear = viewModel.hasBlueGear.value,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // -------------------------------------------------------------
            // 3. Narrative Story Card (Single-view Content Panel - Wireframe Image 1 Match)
            // -------------------------------------------------------------
            ComicCard(
                backgroundColor = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .shake(viewModel.shakeTrigger.value)
                    .padding(vertical = 10.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    // Story Time Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STORY: ${viewModel.currentStoryTitle.value.uppercase()}",
                            color = MutedText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(
                            text = "📖",
                            fontSize = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Narrative story text content (styled with elegant Poppins matching)
                    Text(
                        text = viewModel.currentStoryText.value,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Medium,
                        color = DarkText,
                        lineHeight = 28.sp,
                        textAlign = TextAlign.Start,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Playful and sleek progress bar that appears when Pip reads
                    AnimatedVisibility(
                        visible = ttsState is TtsManager.TtsState.Speaking,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp)
                                .testTag("audio_playback_progress_container")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "PIP IS READING...",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PrimaryPurple,
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "${(ttsProgress * 100).toInt()}%",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PrimaryPurple
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))

                            // Thick linear progress bar track and filling
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .background(Color(0xFFF1F5F9), RoundedCornerShape(100))
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(100))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(ttsProgress.coerceIn(0f, 1f))
                                        .fillMaxHeight()
                                        .background(
                                            brush = Brush.horizontalGradient(
                                                colors = listOf(PrimaryPurple, Color(0xFFA855F7))
                                            ),
                                            shape = RoundedCornerShape(100)
                                        )
                                )
                            }
                        }
                    }
                }
            }

            // Big Wireframe Read Button placed directly below the Story Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (ttsState is TtsManager.TtsState.Speaking) {
                        // "Stop Speech" Button
                        ComicButton(
                            onClick = { 
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.stopStory() 
                            },
                            backgroundColor = Color(0xFFEF4444),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("stop_reading_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Stop Reading",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // "Read Me a Story" Big Play Button
                            ComicButton(
                                onClick = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.readStory()
                                },
                                backgroundColor = PrimaryPurple,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("read_me_story_button")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (ttsState is TtsManager.TtsState.Preparing) "Preparing..." else "Read Me a Story",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                }
                            }

                            // Show small Replay Story icon button if audio finished
                            if (ttsState is TtsManager.TtsState.Success) {
                                ComicButton(
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.readStory()
                                    },
                                    backgroundColor = MidnightIndigo,
                                    modifier = Modifier
                                        .height(48.dp)
                                        .testTag("replay_story_button")
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center,
                                        modifier = Modifier.padding(horizontal = 6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Refresh,
                                            contentDescription = "Replay Story",
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Replay",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Fail/Error message handling
                    viewModel.apiErrorMessage.value?.let { errorMsg ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorMsg,
                            color = Color(0xFFEF4444),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .testTag("api_error_text")
                                .padding(horizontal = 6.dp)
                        )
                    }
                }
            }

            // -------------------------------------------------------------
            // 4. Interactive Data-Driven Pop Quiz (Wireframe Image 2 Match)
            // -------------------------------------------------------------
            // The JSON question reveals smoothly or manual skip allows answering
            AnimatedVisibility(
                visible = viewModel.isQuizRevealed.value,
                enter = slideInVertically(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) + fadeIn(),
                exit = slideOutVertically() + fadeOut()
            ) {
                val quiz = viewModel.currentQuizQuestion.value
                if (quiz != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        // Section header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "POP QUIZ",
                                color = PrimaryPurple,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(end = 8.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(1.dp)
                                    .background(PrimaryPurple.copy(alpha = 0.15f))
                            )
                        }

                        // Wide elegant card representing the main quiz question
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(elevation = 2.dp, shape = RoundedCornerShape(24.dp))
                                .background(Color.White, RoundedCornerShape(24.dp))
                                .border(1.dp, BorderLight, RoundedCornerShape(24.dp))
                                .padding(20.dp)
                                .testTag("quiz_section_card")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(PrimaryPurple.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "⚡ MINI QUIZ",
                                            color = PrimaryPurple,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp
                                        )
                                    }

                                    // Skip/Reload state
                                    IconButton(
                                        onClick = {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            viewModel.retryQuiz()
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Refresh,
                                            contentDescription = "Retry",
                                            tint = MidnightIndigo.copy(alpha = 0.6f),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Dynamic question from modern text flow
                                Text(
                                    text = quiz.question,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MidnightIndigo,
                                    textAlign = TextAlign.Start,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                // Dynamic Option Choices (List layout with circular Radio Button indicator on the far right)
                                quiz.options.forEachIndexed { i, option ->
                                    val isSelectedCorrectOption = viewModel.quizState.value is QuizState.Correct &&
                                            (viewModel.quizState.value as QuizState.Correct).chosenOption == option
                                            
                                    val isSelectedIncorrectOption = viewModel.quizState.value is QuizState.Incorrect &&
                                            (viewModel.quizState.value as QuizState.Incorrect).chosenOption == option

                                    val isSelected = isSelectedCorrectOption || isSelectedIncorrectOption
                                    val cardBg = when {
                                        isSelectedCorrectOption -> Color(0xFFF0FDF4)
                                        isSelectedIncorrectOption -> Color(0xFFFEF2F2)
                                        else -> Color.White
                                    }

                                    val cardBorderColor = when {
                                        isSelectedCorrectOption -> Color(0xFF22C55E)
                                        isSelectedIncorrectOption -> Color(0xFFEF4444)
                                        else -> Color(0xFFE2E8F0)
                                    }

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 5.dp)
                                            .clickable {
                                                if (viewModel.quizState.value !is QuizState.Correct) {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    viewModel.selectQuizOption(option)
                                                }
                                            }
                                            .testTag("quiz_option_$i")
                                            .background(cardBg, RoundedCornerShape(16.dp))
                                            .border(1.5.dp, cardBorderColor, RoundedCornerShape(16.dp))
                                            .padding(horizontal = 16.dp, vertical = 14.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            // Left: Option text
                                            Text(
                                                text = option,
                                                color = DarkText,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                modifier = Modifier.weight(1f)
                                            )

                                            Spacer(modifier = Modifier.width(12.dp))

                                            // Right: Radio button circular indicator style (outline or inner fill dot)
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .border(
                                                        width = 2.dp,
                                                        color = when {
                                                            isSelectedCorrectOption -> Color(0xFF22C55E)
                                                            isSelectedIncorrectOption -> Color(0xFFEF4444)
                                                            else -> Color(0xFFCBD5E1)
                                                        },
                                                        shape = CircleShape
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (isSelectedCorrectOption) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(12.dp)
                                                            .background(Color(0xFF22C55E), CircleShape)
                                                    )
                                                } else if (isSelectedIncorrectOption) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(12.dp)
                                                            .background(Color(0xFFEF4444), CircleShape)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // Success / Award coins banner
                                if (viewModel.quizState.value is QuizState.Correct) {
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFFF0FDF4), RoundedCornerShape(12.dp))
                                            .border(1.5.dp, Color(0xFFBBF7D0), RoundedCornerShape(12.dp))
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Star,
                                            contentDescription = null,
                                            tint = Color(0xFFEAB308),
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Excellent Job! You earned 10 Coins!",
                                            color = Color(0xFF15803D),
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.sp,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Quick access manual reveal button if TTS hasn't been played
            if (!viewModel.isQuizRevealed.value) {
                TextButton(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        viewModel.isQuizRevealed.value = true
                    },
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .testTag("show_quiz_anyway_button")
                ) {
                    Text(
                        "Skip to Quiz ➜",
                        color = ImmersiveTextSub.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // -------------------------------------------------------------
            // 5. Stories Directory Slider (Peblo Story Selection)
            // -------------------------------------------------------------
            Spacer(modifier = Modifier.height(10.dp))
            ComicCard(
                backgroundColor = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "📚 Local Story Directory",
                        color = ImmersiveTextDark,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (idx in 0..2) {
                            val isSelected = viewModel.currentStoryIndex.value == idx
                            val cardBg = if (isSelected) ImmersiveCyan else Color.White
                            val inkColor = if (isSelected) Color.White else ImmersiveTextDark
                            val borderCol = if (isSelected) ImmersiveCyan else Color(0xFFE2E8F0)
                            val labelText = when (idx) {
                                0 -> "🤖 Robot Pip"
                                1 -> "🐰 Lulu's Hat"
                                else -> "🦉 Ollie's snack"
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(cardBg, RoundedCornerShape(12.dp))
                                    .border(1.5.dp, borderCol, RoundedCornerShape(12.dp))
                                    .clickable {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        viewModel.selectStory(idx)
                                    }
                                    .testTag("story_option_$idx")
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = labelText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = inkColor,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }

            // -------------------------------------------------------------
            // 6. Magic AI Maker (Gemini API custom content trigger)
            // -------------------------------------------------------------
            Spacer(modifier = Modifier.height(10.dp))
            ComicCard(
                backgroundColor = Color.White,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "✨ Peblo Magic AI Story Maker",
                        color = ImmersiveTextDark,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Text(
                        text = "Type any child's favorite characters or events and Pip will generate a personalized short story and quiz!",
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        color = ImmersiveTextSub,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Topic Input Field styled nicely with M3 outline
                        TextField(
                            value = viewModel.customTopic.value,
                            onValueChange = { viewModel.customTopic.value = it },
                            placeholder = { Text("e.g. 'Little Monkey flying a balloon'", fontSize = 12.sp, color = ImmersiveTextSub.copy(alpha = 0.5f)) },
                            singleLine = true,
                            enabled = !viewModel.isGeneratingStory.value,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                keyboardController?.hide()
                                focusManager.clearFocus()
                                viewModel.generateStoryFromAi()
                             }),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                disabledContainerColor = Color(0xFFF1F5F9),
                                focusedIndicatorColor = ImmersiveCyan,
                                unfocusedIndicatorColor = Color(0xFFE2E8F0),
                                disabledIndicatorColor = Color.Transparent,
                                focusedTextColor = ImmersiveTextDark,
                                unfocusedTextColor = ImmersiveTextDark
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .border(1.5.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                                .clip(RoundedCornerShape(12.dp))
                                .testTag("ai_topic_input")
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        // Generate Submit FAB Button
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .shadow(elevation = 2.dp, shape = RoundedCornerShape(12.dp), spotColor = ImmersiveCyan)
                                .background(
                                    if (viewModel.isGeneratingStory.value) Color(0xFFE2E8F0) else ImmersiveCyan,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable(enabled = !viewModel.isGeneratingStory.value) {
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.generateStoryFromAi()
                                }
                                .testTag("ai_generate_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (viewModel.isGeneratingStory.value) {
                                CircularProgressIndicator(
                                    color = ImmersiveCyan,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(20.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Star,
                                    contentDescription = "Generate Story",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 7. Immersive Footer Daily Mission status
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(ImmersiveOrange, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "DAILY MISSION: 2/3 STORIES",
                    color = ImmersiveTextSub.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // -------------------------------------------------------------
        // Overlays: Confetti Particle explosion celebrate correct choice
        // -------------------------------------------------------------
        ConfettiEffect(
            trigger = viewModel.confettiTrigger.value,
            modifier = Modifier.fillMaxSize()
        )
    }
}

// -------------------------------------------------------------
// Playful visual widgets
// -------------------------------------------------------------

@Composable
fun TtsWaveformVisualizer() {
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val heights = listOf(
        infiniteTransition.animateFloat(
            initialValue = 4f, targetValue = 20f,
            animationSpec = infiniteRepeatable(tween(400, easing = EaseInOutSine), RepeatMode.Reverse), label = "h1"
        ),
        infiniteTransition.animateFloat(
            initialValue = 10f, targetValue = 30f,
            animationSpec = infiniteRepeatable(tween(250, easing = EaseInOutSine), RepeatMode.Reverse), label = "h2"
        ),
        infiniteTransition.animateFloat(
            initialValue = 15f, targetValue = 40f,
            animationSpec = infiniteRepeatable(tween(350, easing = EaseInOutSine), RepeatMode.Reverse), label = "h3"
        ),
        infiniteTransition.animateFloat(
            initialValue = 6f, targetValue = 24f,
            animationSpec = infiniteRepeatable(tween(300, easing = EaseInOutSine), RepeatMode.Reverse), label = "h4"
        )
    )

    Row(
        modifier = Modifier
            .padding(top = 4.dp)
            .height(44.dp)
            .testTag("waveform_visualizer"),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Pip is speaking... 🔊 ",
            fontSize = 11.sp,
            color = ImmersiveCyan,
            weight = FontWeight.Black,
            modifier = Modifier.padding(end = 4.dp)
        )
        heights.forEach { anim ->
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(anim.value.dp)
                    .background(ImmersiveCyan, RoundedCornerShape(100))
            )
        }
    }
}

// Custom typography check for local modifiers
@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: androidx.compose.ui.unit.TextUnit = androidx.compose.ui.unit.TextUnit.Unspecified,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    lineHeight: androidx.compose.ui.unit.TextUnit = androidx.compose.ui.unit.TextUnit.Unspecified,
    textAlign: TextAlign? = null,
    weight: FontWeight? = null
) {
    androidx.compose.material3.Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontWeight = weight ?: fontWeight,
        fontFamily = fontFamily,
        lineHeight = lineHeight,
        textAlign = textAlign
    )
}

// -------------------------------------------------------------
// Playful Pop Art / Comic Layout Modifiers and Containers - Now Styled with Immersive UI
// -------------------------------------------------------------

@Composable
fun ComicCard(
    backgroundColor: Color,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .shadow(
                elevation = 8.dp,
                shape = RoundedCornerShape(24.dp),
                ambientColor = Color(0xFF432818).copy(alpha = 0.05f),
                spotColor = Color(0xFF432818).copy(alpha = 0.08f)
            )
            .background(backgroundColor, RoundedCornerShape(24.dp))
            .border(1.dp, ImmersiveCardBorder, RoundedCornerShape(24.dp))
    ) {
        content()
    }
}

@Composable
fun ComicButton(
    onClick: () -> Unit,
    backgroundColor: Color,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    val scaleFactor by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1.0f,
        label = "button_scale"
    )

    Box(
        modifier = modifier
            .scale(scaleFactor)
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(16.dp),
                ambientColor = backgroundColor.copy(alpha = 0.25f),
                spotColor = backgroundColor.copy(alpha = 0.35f)
            )
            .background(backgroundColor, RoundedCornerShape(16.dp))
            .clickable {
                onClick()
            }
            .padding(vertical = 12.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
