package com.example.audio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    sealed interface TtsState {
        object Idle : TtsState
        object Preparing : TtsState
        object Speaking : TtsState
        object Success : TtsState
        data class Error(val message: String) : TtsState
    }

    private var tts: TextToSpeech? = null
    private val _state = MutableStateFlow<TtsState>(TtsState.Idle)
    val state = _state.asStateFlow()

    private val _progress = MutableStateFlow<Float>(0f)
    val progress = _progress.asStateFlow()

    private var isInitialized = false
    private var pendingText: String? = null
    private var currentTextLength: Int = 1

    init {
        _state.value = TtsState.Preparing
        try {
            tts = TextToSpeech(context, this)
        } catch (e: Exception) {
            _state.value = TtsState.Error("Init failed: ${e.localizedMessage}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                _state.value = TtsState.Error("US language not supported on this device.")
                Log.e("TtsManager", "Language not supported")
            } else {
                isInitialized = true
                _state.value = TtsState.Idle
                setupProgressListener()
                pendingText?.let {
                    speak(it)
                    pendingText = null
                }
            }
        } else {
            isInitialized = false
            _state.value = TtsState.Error("Initialization check failed.")
            Log.e("TtsManager", "Initialization failed")
        }
    }

    private fun setupProgressListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _state.value = TtsState.Speaking
                _progress.value = 0f
                Log.d("TtsManager", "Speech started")
            }

            override fun onDone(utteranceId: String?) {
                _state.value = TtsState.Success
                _progress.value = 1f
                Log.d("TtsManager", "Speech finished")
            }

            @Deprecated("Deprecated in Java", ReplaceWith("onError(utteranceId, -1)"))
            override fun onError(utteranceId: String?) {
                _state.value = TtsState.Error("Playback error occurred.")
                _progress.value = 0f
                Log.e("TtsManager", "Speech error")
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                _state.value = TtsState.Error("Playback error code: $errorCode")
                _progress.value = 0f
                Log.e("TtsManager", "Speech error code: $errorCode")
            }

            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                super.onRangeStart(utteranceId, start, end, frame)
                if (currentTextLength > 0) {
                    val p = start.toFloat() / currentTextLength
                    _progress.value = p.coerceIn(0f, 1f)
                }
            }
        })
    }

    fun speak(text: String) {
        if (!isInitialized) {
            pendingText = text
            _state.value = TtsState.Preparing
            return
        }

        _state.value = TtsState.Preparing
        currentTextLength = text.length.coerceAtLeast(1)
        _progress.value = 0f
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "peblo_story")
        }

        val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "peblo_story")
        if (result == TextToSpeech.ERROR) {
            _state.value = TtsState.Error("Speak call failed.")
        }
    }

    fun stop() {
        tts?.stop()
        _progress.value = 0f
        if (isInitialized) {
            _state.value = TtsState.Idle
        }
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
        _progress.value = 0f
        _state.value = TtsState.Idle
    }
}
