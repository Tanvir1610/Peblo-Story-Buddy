package com.example.model

data class QuizQuestion(
    val question: String,
    val options: List<String>,
    val answer: String
)
